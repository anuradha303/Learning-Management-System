<?php

$user="root";
$password="";
$db="db";

$db=new mysqli('localhost',$user,$password,$db)or die();

echo"connected";

$username=$_POST['nme'];
$pass=$_POST['psw'];

$username=stripcslashes($username);
$pass=stripcslashes($pass);

$username= mysql_real_escape_string;
$pass=mysql_real_escape_string;

mysql_connect("localhost", "root","");
mysql_select_db("db");


$result =  mysql_query("select * from student where ID= '$username' and Password ='$password'") or die ("Failed".mysql_error());

$row = mysql_fetch_array($result);
$url="http://localhost:84/lms/faculties/lms2.html";


if($row['ID']==$username && $row['Password'] == $password)
{
    header("Location:$url");
    
}

else
{
echo "Failed to login";    
}



?>

