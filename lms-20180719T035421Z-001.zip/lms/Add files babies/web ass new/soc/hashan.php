<DOCTYPE html>
<html>
<head>
  <title> NSBM Learning Management System </title>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="phpart.css" type="text/css" rel="stylesheet">
    

</head>
  	
<body>
  
  <hr> 
  <div id="one">
    <br>
    <div>
	<img src="NSBM.jpg" alt="logo" align="right" height="110" width="220"> 
    </div>
	<div>
	<hr>
	<h1 align="center"> National School of Business Management </h1>
	<hr>
	<h1> <marquee behavior="alternate"> LEARNING MANAGEMENT SYSTEM </marquee> </h1>
	</div>
  </div>
  <hr>
    



  <div class="image"> 
        <ul>  <h1 class="soc">School of Computing</h1></ul>

<?php
    if(isset($_GET['modulename'])){
        $m_name=$_GET['modulename'];
                
?>
 
    <h1 class="Module"><?php   echo $m_name;   ?></h1>
        
   <h2>Download Your Module Subjects:</h2>
   <ul>
    <table  class="down">
                <tbody>
                    <?php
                    
                        $dir    = ("./uploads and downloads/SOC/$m_name/down/");
                        $files = array_slice(scandir($dir),2);
                        foreach($files as $value){
                            echo "<tr>";
                            
                            echo "<td><a href='./uploads and downloads/SOC/$m_name/down/{$value}'>{$value}</a></td>";
                            echo "</tr>";
                        }
                    ?> 
                </tbody>
            </table>
    
   </ul>
      
          
    <?php
        
    }
        ?>
    
    <h2>Upload Your Assignments</h2>

    <form action="#" method="post" enctype="multipart/form-data">
    Select file to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload File" name="submit">
</form>

    
    <?php
    if(isset($_POST['submit'])){
$target_path = "./uploads and downloads/SOC/$m_name/up/";
$target_path = $target_path . basename( $_FILES['fileToUpload']['name']); 

if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target_path)) {
    echo "The file ".  basename( $_FILES['fileToUpload']['name']). 
    " has been uploaded";
} else{
    echo "There was an error uploading the file, please try again!";
}
    }
    

?>
   
  


       <br><br><br></div>
 <footer>
  <p align="center"> National School of Business Management: Pitipana Mahenwaththa,Homagama,Colombo, Sri Lanka. 
Telephone: +94(11) 567 2545|5673535 - Email:info@nsbm.lk </p>
</footer>
  

</body>
 
  
</html>